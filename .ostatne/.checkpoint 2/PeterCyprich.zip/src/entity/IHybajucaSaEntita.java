package entity;

/**
 * Interface pre entitu, ktora sa hybe
 */
public interface IHybajucaSaEntita {
    void tikPohybu();
}
