package entity.rastliny.utociaceRastliny.nestrielajuceRastliny;

public abstract class NestrielajucaRastlina extends entity.rastliny.Rastlina {
    public NestrielajucaRastlina(int x, int y, String nazovAnimacieObrazku, int pocetObrazokov) {
        super(x, y, nazovAnimacieObrazku, pocetObrazokov);
    }
}
