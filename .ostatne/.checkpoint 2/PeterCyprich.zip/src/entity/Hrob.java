package entity;

public class Hrob extends Entita {
    public Hrob(int x, int y, String nazovAnimacieObrazku, int pocetObrazokov) {
        super(x, y, nazovAnimacieObrazku, pocetObrazokov);
    }
}
