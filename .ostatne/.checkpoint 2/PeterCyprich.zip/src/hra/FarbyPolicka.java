package hra;

/**
 * Reprezentuje farby policok
 */
public enum FarbyPolicka {
    ZELENA1,
    ZELENA2,
    ZELENA3;
}
