# Plants vs. Zombies
[![wakatime](https://wakatime.com/badge/user/4c514061-8f41-4da2-97ea-f2b4906774a3/project/018de09a-faf5-4742-be85-04cba8f5759b.svg)](https://wakatime.com/badge/user/4c514061-8f41-4da2-97ea-f2b4906774a3/project/018de09a-faf5-4742-be85-04cba8f5759b)  
Moja semestrálna práca z predmetu Informatika 2

