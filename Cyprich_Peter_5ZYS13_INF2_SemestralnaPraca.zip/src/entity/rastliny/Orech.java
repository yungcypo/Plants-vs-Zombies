package entity.rastliny;

public class Orech extends Rastlina {
    /**
     * Vytvori Orech
     *
     * @param x suradnica x
     * @param y suradnica y
     */
    public Orech(int x, int y) {
        super(x, y, "orech", 120, 60);
    }
}
