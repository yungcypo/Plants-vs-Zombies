package entity;

/**
 * Interface pre entitu, ktora sa hybe
 */
public interface IHybajucaSaEntita {
    /**
     * Trieda musi implementovat metodu na pohyb
     */
    void tikPohybu();
}
