package hra.hud;

import fri.shapesge.BlokTextu;
import fri.shapesge.Obdlznik;
import fri.shapesge.Obrazok;
import fri.shapesge.StylFontu;
import fri.shapesge.Manazer;
import hra.Hra;
import hra.IKlikatelne;

import java.util.ArrayList;
import java.util.List;

/**
 * Head-Up Display.
 * Reprezentuje dolny riadok s kartami a poctom slniecok
 */
public class HUD implements IKlikatelne {
    private final int x;
    private final int y;
    private final Obdlznik pozadie;
    private final ArrayList<Karta> karty;
    private final ArrayList<TypKarty> typyKariet;
    private final int sirkaZvyraznenia = 10;
    private final int padding = this.sirkaZvyraznenia * 2;
    private Karta zvyraznenaKarta = null;
    private final Obrazok obrazokSlnka;
    private int pocetSlniek = 500;
    private final BlokTextu text;

    /**
     * Vytvori HUD
     */
    public HUD() {
        this.karty = new ArrayList<>();
        this.typyKariet = new ArrayList<>();
        this.typyKariet.addAll(List.of(TypKarty.values()));

        this.x = 50;
        this.y = 550;

        this.pozadie = new Obdlznik(this.x, this.y);
        this.pozadie.zmenStrany(
                this.typyKariet.size() * (100 + this.padding) + this.padding + 150,
                150 + this.padding * 2
        );
        this.pozadie.zmenFarbu("hud");
        this.pozadie.zobraz();

        for (int i = 0; i < this.typyKariet.size(); i++) {
            this.karty.add(new Karta(
                    this.x + this.sirkaZvyraznenia + i * (100 + this.padding) + 150,
                    this.y + this.sirkaZvyraznenia,
                    this.typyKariet.get(i),
                    this.sirkaZvyraznenia
            ));
        }

        this.obrazokSlnka = new Obrazok("resources/obrazky/slnko.png", this.x + 30, this.y + 25);
        this.obrazokSlnka.zobraz();
        this.text = new BlokTextu(String.valueOf(this.pocetSlniek), this.x + 40, this.y + 165);
        this.text.zmenFont("Arial", StylFontu.BOLD, 45);
        this.text.zmenFarbu("#ffffff");
        this.text.zobraz();
    }

    /**
     * Prechadza zoznam kariet a prikaze manazerovi z parametra, aby ich spravoval
     *
     * @param manazer manazer, ktory ma spravovat karty
     */
    public void spravujKarty(Manazer manazer) {
        for (Karta k : this.karty) {
            manazer.spravujObjekt(k);
        }
    }

    /**
     * Zmeni pocet slniecok na HUD.
     * Prechadza vsetkymi kartami a vola metodu zmenPocetSlniecok()
     *
     * @param hracoveSlniecka pocet slniecok hraca
     */
    public void moznoSaBudeDatKliknut(int hracoveSlniecka) {
        for (Karta k : this.karty) {
            k.moznoSaBudeDatKliknut(hracoveSlniecka);
        }
        this.zmenPocetSlniecok(hracoveSlniecka);
    }

    /**
     * Vola metodu metodu moznoSaBudeDatKliknut() s parametrom hracoveSlniecka z triedy Hra
     */
    public void moznoSaBudeDatKliknut() {
        this.moznoSaBudeDatKliknut(Hra.getHra().getHracoveSlniecka());
    }

    /**
     * Metoda, ktoru zavola trieda Hra, ked sa kliklo na HUD.
     * Prechadza vsetkymi kartami a zistuje, ci na ne bolo kliknute.
     * Ak sa kliklo na kartu a dana karta moze byt zvyraznena, zvyrazni ju
     *
     * @param x suradnica x, na ktoru sa kliklo
     * @param y suradnica y, na ktoru sa kliklo
     */
    public void klikloSaNaHUD(int x, int y) {
        for (Karta k : this.karty) {
            // ak je karta nacitana a hrac ma dostatok slniecok
            if (k.getMozeBytKliknuta()) {
                if (k.boloNaMnaKliknute(x, y)) {
                    this.odzvyrazniKarty();

                    // ak nie je ziadna karta zvyraznena
                    if (this.zvyraznenaKarta == null) {
                        this.zvyraznenaKarta = k;
                        this.zvyraznenaKarta.setZvyraznena(true);
                    } else {
                        // ak uz je najaka karta zvyraznena
                        if (this.zvyraznenaKarta == k) {
                            // ak sa znova kliklo na kartu, ktora uz je zvyraznena, zrusi sa zvyraznenie
                            this.zvyraznenaKarta.setZvyraznena(false);
                            this.zvyraznenaKarta = null;
                        } else {
                            // ak sa kliklo na inu kartu, zvyrazni novu
                            this.zvyraznenaKarta = k;
                            this.zvyraznenaKarta.setZvyraznena(true);
                        }
                    }
                    break;
                }
            }
        }
    }

    /**
     * Vrati zvyraznenu kartu
     *
     * @return zvyraznena karta
     */
    public Karta getZvyraznenaKarta() {
        return this.zvyraznenaKarta;
    }

    /**
     * Zrusi zvyraznenie kariet a nastavi zvyraznenu kartu na null
     */
    public void odzvyrazniKarty() {
        for (Karta k : this.karty) {
            if (k.getZvyraznena()) {
                k.setZvyraznena(false);
            }
        }
        this.zvyraznenaKarta = null;
    }

    /**
     * Vrati suradnicu x laveho okraja pozadia
     *
     * @return x suradnica laveho okraja pozadia
     */
    public int getX() {
        return this.x;
    }

    /**
     * Vrati suradnicu y horneho okraja pozadia
     *
     * @return y suradnica horneho okraja pozadia
     */
    public int getY() {
        return this.y;
    }

    /**
     * Vrati suradnicu x praveho okraja pozadia
     *
     * @return x suradnica praveho okraja pozadia
     */
    public int getX2() {
        return this.x + this.karty.size() * (100 + this.padding) + this.padding + 150;
    }

    /**
     * Vrati suradnicu y dolneho okraja pozadia
     *
     * @return y suradnica dolneho okraja pozadia
     */
    public int getY2() {
        return this.y + this.padding * 2 + 150;
    }

    /**
     * Vrati hodnotu, ci sa kliklo na hud.
     * Porovnava suradnice mysky s okrajmi HUD.
     *
     * @param x x-ova suradnica mysky pri kliknuti
     * @param y y-ova suradnica mysky pri kliknuti
     * @return true, ak bolo kliknute na HUD, inak false
     */
    @Override
    public boolean boloNaMnaKliknute(int x, int y) {
        return x > this.x && x < this.getX2() && y > this.y && y < this.getY2();
    }

    /**
     * Zmeni pocet slniecok na HUD
     *
     * @param pocet novy pocet slniecok
     */
    public void zmenPocetSlniecok(int pocet) {
        this.pocetSlniek = pocet;
        this.text.zmenText(String.valueOf(this.pocetSlniek));
    }
}
